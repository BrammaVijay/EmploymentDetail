package com.example.employmentdetailactivity.model

data class AddressX(
    val city: String,
    val geo: GeoX,
    val street: String,
    val suite: String,
    val zipcode: String
)