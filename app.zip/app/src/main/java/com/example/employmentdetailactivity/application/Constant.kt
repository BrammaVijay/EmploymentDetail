package com.example.employmentdetailactivity.application

object Constant {

        const val BASE_URL="https://jsonplaceholder.typicode.com/"
}