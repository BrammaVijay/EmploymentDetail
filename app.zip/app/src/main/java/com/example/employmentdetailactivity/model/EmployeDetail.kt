package com.example.employmentdetailactivity.model

import com.example.employmentdetailactivity.model.EmployeDetailItem

class EmployeDetail : ArrayList<EmployeDetailItem>()