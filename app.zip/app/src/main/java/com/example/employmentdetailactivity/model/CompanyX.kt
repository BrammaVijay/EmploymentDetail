package com.example.employmentdetailactivity.model

data class CompanyX(
    val bs: String,
    val catchPhrase: String,
    val name: String
)