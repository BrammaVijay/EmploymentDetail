package com.example.employmentdetailactivity.model

data class GeoX(
    val lat: String,
    val lng: String
)